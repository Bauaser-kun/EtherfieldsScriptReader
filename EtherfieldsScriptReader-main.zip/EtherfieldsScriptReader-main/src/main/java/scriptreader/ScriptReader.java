package scriptreader;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

public class ScriptReader  {
    public void openFile(String filename) throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file;
        file = new File("./" + filename + ".txt").getAbsoluteFile(); 
        //Desktop.getDesktop().open(file);

        InputStream inputStream = getClass().getResourceAsStream("/scripts/" + filename + ".txt");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            
        reader.lines().forEach(line -> {
            System.out.println(line);
        });

    }
}
