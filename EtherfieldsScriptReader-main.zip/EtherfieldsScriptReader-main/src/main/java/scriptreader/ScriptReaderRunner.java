package scriptreader;

import java.io.IOException;
import java.util.Scanner;

public class ScriptReaderRunner {
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) throws IOException {
        int status = 1;
        ScriptReader reader = new ScriptReader();
        
        do {
            System.out.println("to exit type: 'exit' ");
            System.out.println("provide script name to be opened");
            String input = scanner.nextLine();

            if (input.toLowerCase().equals("exit")) {
                status = 0;
            } else {
                reader.openFile(input);
            }
        } while (status == 1);
    }
}
